运行环境：OS X 10.10
运行命令：执行make命令后运行test文件，需要安装imagemagick等依赖库。Linux下也可以执行，需要cimg-dev等依赖库。